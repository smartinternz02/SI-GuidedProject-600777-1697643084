# app.py
import joblib
from flask import Flask, jsonify, abort, make_response, request, render_template
from flask import Flask,render_template,url_for,request,send_from_directory

model = joblib.load("RF_uncompressed.joblib")

app = Flask(__name__)

tasks = [
    {
        'id': 1,
        'title': u'Buy groceries',
        'description': u'Milk, Cheese, Pizza, Fruit, Tylenol', 
        'done': False
    },
    {
        'id': 2,
        'title': u'Learn Python',
        'description': u'Need to find a good Python tutorial on the web', 
        'done': False
    }
]

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/tasks', methods=['POST'])
def predict():
    A1_Score=request.form['A1_Score']
    A2_Score=request.form['A2_Score']
    A3_Score=request.form['A3_Score']
    A4_Score=request.form['A4_Score']
    A5_Score=request.form['A5_Score']
    A6_Score=request.form['A6_Score']
    A7_Score=request.form['A7_Score']
    A8_Score=request.form['A8_Score']
    A9_Score=request.form['A9_Score']
    A10_Score=request.form['A10_Score']
    age=request.form['age']
    result=request.form['result']
    Jundice=request.form['Jundice']
    Austim=request.form['Austim']
    Ethnicity=request.form['Ethnicity']
    X=[[int(request.form['A1_score']),int(request.form['A2_score']),int(request.form['A3_score']),int(request.form['A4_score']),int(request.form['A5_score']),int(request.form['A6_score']),int(request.form['A7_score']),int(request.form['A8_score']),int(request.form['A9_score']),int(request.form['A10_score']),]]
    prediction=model.predict(X)[0]
    return render_template('predict.html',prediction='Detected_YES {}'.format(X))


@app.route('/tasks/<int:task_id>', methods=['GET'])
def get_task(task_id):
    task = [task for task in tasks if task['id'] == task_id]
    if len(task) == 0:
        abort(404)
    return jsonify({'task': task[0]})


@app.route('/tasks', methods=['POST'])
def create_task():
    if not request.json or not 'title' in request.json:
        abort(400)
    task = {
        'id': tasks[-1]['id'] + 1,
        'title': request.json['title'],
        'description': request.json.get('description', ""),
        'done': False
    }
    tasks.append(task)
    return jsonify({'task': task}), 201


@app.route('/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    task = [task for task in tasks if task['id'] == task_id]
    if len(task) == 0:
        abort(404)
    if not request.json:
        abort(400)
    if 'title' in request.json and type(request.json['title']) != unicode:
        abort(400)
    if 'description' in request.json and type(request.json['description']) is not unicode:
        abort(400)
    if 'done' in request.json and type(request.json['done']) is not bool:
        abort(400)
    task[0]['title'] = request.json.get('title', task[0]['title'])
    task[0]['description'] = request.json.get('description', task[0]['description'])
    task[0]['done'] = request.json.get('done', task[0]['done'])
    return jsonify({'task': task[0]})


@app.route('/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    task = [task for task in tasks if task['id'] == task_id]
    if len(task) == 0:
        abort(404)
    tasks.remove(task[0])
    return jsonify({'result': True})


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)


if __name__ == '__main__':
    app.run(debug=True)
